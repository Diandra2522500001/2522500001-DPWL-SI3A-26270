<?php
$config = [];
$config['base_url'] = 'http://localhost/dpwl-2522500001/';
$config['index_page'] = '';