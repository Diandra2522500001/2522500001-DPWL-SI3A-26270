<?php
// Nama Berkas - application\config\routes.php
$route = [];

// Route P2/P3 - dipertahankan, penyesuaian terhadap penulisan nama Controller.
// $route['default_controller'] = 'Home'; // dimatikan pada P6 karena penulisan index.php dihilangkan pada URL aplikasi
$route['default_controller'] = 'Katalog_controller'; // karena penulisan index.php dihilangkan pada URL aplikasi
$route['info/(:any)'] = 'Home/info/$1';
$route['login'] = 'Auth/login';
$route['auth/login'] = 'Auth/login';
$route['auth/logout'] = 'Auth/logout';
$route['admin'] = 'Admin/index';

// Route P4: semua proses CRUD admin dipindahkan di URL admin/madmin.
$route['admin/madmin'] = 'Madmin_controller/index';
$route['admin/madmin/tambah'] = 'Madmin_controller/tambah';
$route['admin/madmin/ubah/(:any)'] = 'Madmin_controller/ubah/$1';
$route['admin/madmin/hapus/(:any)'] = 'Madmin_controller/hapus/$1';

// Route P5
// dari href(menu), diproses ke Mobil_controller dengan mengerjakan method index() yang memanggil 
// admin\mobil_view
$route['admin/mobil'] = 'Mobil_controller/index';
$route['admin/mobil/tambah'] = 'Mobil_controller/tambah';
$route['admin/mobil/ubah/(:any)'] = 'Mobil_controller/ubah/$1';
$route['admin/mobil/hapus/(:any)'] = 'Mobil_controller/hapus/$1';

// Route P6
$route['katalog'] = 'Katalog_controller/index';
$route['katalog/detail/(:any)'] = 'Katalog_controller/detail/$1';
$route['auth/register'] = 'Auth/register';
$route['auth/login-penyewa'] = 'Auth/loginPenyewa';
$route['auth/logout-penyewa'] = 'Auth/logoutPenyewa';
$route['penyewa/profil'] = 'Penyewa_controller/profil';

// Route P7 - Transaksi, Keranjang, dan Checkout
$route['transaksi/tambah'] = 'Transaksi_controller/tambah';
$route['transaksi/keranjang'] = 'Transaksi_controller/keranjang';
$route['transaksi/perbarui-periode'] = 'Transaksi_controller/perbaruiPeriode';
$route['transaksi/hapus'] = 'Transaksi_controller/hapus';
$route['transaksi/hapus/(:any)'] = 'Transaksi_controller/hapus/$1';
$route['transaksi/checkout'] = 'Transaksi_controller/checkout';

// Route UTS P8 - Manajemen Penyewa (sisi Admin)
$route['admin/penyewa'] = 'Mpenyewa_controller/index';
$route['admin/penyewa/tambah'] = 'Mpenyewa_controller/tambah';
$route['admin/penyewa/ubah/(:any)'] = 'Mpenyewa_controller/ubah/$1';
$route['admin/penyewa/hapus/(:any)'] = 'Mpenyewa_controller/hapus/$1';
// Route P9 - Pembayaran DP (penyewa) dan Verifikasi Pembayaran (admin)
// Kode pembayaran memuat '/', sehingga dikirim lewat query string ?kode_bayar=
$route['pembayaran'] = 'Pembayaran_controller/index';
$route['pembayaran/detail'] = 'Pembayaran_controller/detail';
$route['pembayaran/unggah'] = 'Pembayaran_controller/unggah';
$route['pembayaran/bukti'] = 'Pembayaran_controller/bukti';
$route['admin/pembayaran'] = 'Mpembayaran_controller/index';
$route['admin/pembayaran/detail'] = 'Mpembayaran_controller/detail';
$route['admin/pembayaran/bukti'] = 'Mpembayaran_controller/bukti';
$route['admin/pembayaran/verifikasi'] = 'Mpembayaran_controller/verifikasi';
